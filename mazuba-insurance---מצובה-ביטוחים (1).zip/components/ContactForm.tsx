
import React, { useState } from 'react';
import { InsuranceType, ContactMessage } from '../types';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState<ContactMessage>({
    name: '',
    phone: '',
    email: '',
    service: '',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    
    // Simulate API call
    setTimeout(() => {
      setStatus('success');
      setFormData({ name: '', phone: '', email: '', service: '', message: '' });
      setTimeout(() => setStatus('idle'), 5000);
    }, 1500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-mazuba-blue rounded-[3rem] p-8 md:p-16 shadow-2xl relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-mazuba-orange/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/5 rounded-full -ml-32 -mb-32 blur-3xl"></div>

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-mazuba-orange font-bold uppercase tracking-widest mb-2">צרו קשר</h2>
            <h3 className="text-4xl font-black text-white mb-6">אנחנו כאן לשירותכם!</h3>
            <p className="text-blue-100 text-lg mb-8 leading-relaxed">
              השאירו פרטים ונחזור אליכם בהקדם. המשרד פועל בימים א'-ה' בין השעות 08:00-16:30.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center text-white">
                <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center ml-4">📞</div>
                <div>
                  <p className="text-sm text-blue-300">טלפון המשרד</p>
                  <p className="text-lg font-bold" dir="ltr">04-9858006</p>
                </div>
              </div>
              <div className="flex items-center text-white">
                <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center ml-4">📧</div>
                <div>
                  <p className="text-sm text-blue-300">דוא"ל</p>
                  <p className="text-lg font-bold">urikadoshi@matzuva.org.il</p>
                </div>
              </div>
            </div>
            
            <div className="mt-12 p-6 bg-white/5 rounded-2xl border border-white/10">
              <p className="text-white font-bold mb-2">קיבלת לינק לפידבק?</p>
              <p className="text-blue-200 text-sm">נשמח מאוד לשמוע מה דעתך על האתר החדש שלנו. בחר "פידבק על האתר" בנושא הפניה.</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-xl">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">שם מלא</label>
                <input 
                  type="text" required name="name" value={formData.name} onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-mazuba-orange outline-none transition-all"
                  placeholder="ישראל ישראלי"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">טלפון</label>
                <input 
                  type="tel" required name="phone" value={formData.phone} onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-mazuba-orange outline-none transition-all"
                  placeholder="050-0000000"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">נושא הפניה</label>
                <select 
                  name="service" value={formData.service} onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-mazuba-orange outline-none transition-all"
                >
                  <option value="">בחר נושא</option>
                  <option value="אחריות מקצועית">אחריות מקצועית</option>
                  <option value="בריאות וסיעוד">בריאות וסיעוד</option>
                  <option value="פנסיה וחיים">פנסיה וחיים</option>
                  <option value="פידבק על האתר">✨ פידבק על האתר החדש</option>
                  <option value="אחר">אחר</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">הודעה</label>
                <textarea 
                  name="message" value={formData.message} onChange={handleChange} rows={3}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-mazuba-orange outline-none transition-all"
                  placeholder="איך נוכל לעזור? או מה דעתך על האתר?"
                ></textarea>
              </div>
              
              <button 
                type="submit"
                disabled={status === 'loading'}
                className={`w-full py-4 rounded-xl text-white font-bold text-lg shadow-lg transition-all ${
                  status === 'loading' ? 'bg-gray-400 cursor-not-allowed' : 'bg-mazuba-orange hover:bg-mazuba-blue active:scale-95'
                }`}
              >
                {status === 'loading' ? 'שולח...' : 'שליחת פרטים'}
              </button>
              
              {status === 'success' && (
                <div className="bg-green-50 text-green-700 p-4 rounded-xl text-center font-medium animate-bounce">
                  הפרטים נשלחו בהצלחה! נחזור אליכם בהקדם.
                </div>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactForm;
