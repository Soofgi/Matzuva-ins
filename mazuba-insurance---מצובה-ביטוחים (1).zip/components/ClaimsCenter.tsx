
import React from 'react';

const ClaimsCenter: React.FC = () => {
  const steps = [
    {
      title: 'דיווח ראשוני',
      description: 'צרו איתנו קשר מיד עם קרות האירוע. אנחנו זמינים עבורכם בטלפון ובבוט החכם.',
      icon: '📞'
    },
    {
      title: 'תיעוד הנזק',
      description: 'צלמו את זירת האירוע, הנזקים לרכוש וכל מסמך רלוונטי (דו"ח משטרה, פרטי צד ג\').',
      icon: '📸'
    },
    {
      title: 'ליווי מלא',
      description: 'מנהל תביעות אישי ילווה אתכם מול חברת הביטוח עד לקבלת הפיצוי המקסימלי.',
      icon: '🤝'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-[3rem] p-10 md:p-20">
        <div className="text-center mb-16">
          <h2 className="text-blue-600 font-bold tracking-widest uppercase mb-2">קרה משהו? אנחנו כאן</h2>
          <p className="text-4xl font-black text-gray-900">מרכז התביעות של מצובה</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="w-20 h-20 bg-white rounded-2xl shadow-lg flex items-center justify-center text-4xl mx-auto mb-6 transform -rotate-6">
                {step.icon}
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{step.title}</h3>
              <p className="text-gray-600 leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col sm:flex-row justify-center gap-6">
          <button className="bg-red-500 hover:bg-red-600 text-white px-8 py-4 rounded-2xl font-bold text-xl shadow-lg transition-all flex items-center justify-center">
            <span className="ml-3">🚨</span>
            דיווח דחוף על תאונה
          </button>
          <button className="bg-white border-2 border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-2xl font-bold text-xl transition-all flex items-center justify-center">
            טפסי תביעה להורדה
          </button>
        </div>
      </div>
    </div>
  );
};

export default ClaimsCenter;
