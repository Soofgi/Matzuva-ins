
import React from 'react';
import { InsuranceType, ServiceItem } from '../types';

const services: ServiceItem[] = [
  {
    id: '1',
    title: 'אחריות מקצועית',
    description: 'התמחות ייחודית לממוני ומהנדסי בטיחות, יועצי נגישות, אגרונומים, אדריכלי נוף, עורכי מבדקים במוסדות חינוך, מהנדסים ויועצי בטיחות אש.',
    icon: '⚖️',
    type: InsuranceType.BUSINESS
  },
  {
    id: '2',
    title: 'בריאות וסיעוד',
    description: 'תכנון והתאמת מערך ההגנות הביטוחי המקיף ביותר לאנשים פרטיים ומשפחות, עם דגש על פתרונות אמיתיים ברגע הצורך.',
    icon: '🏥',
    type: InsuranceType.HEALTH
  },
  {
    id: '3',
    title: 'פנסיה וחיים',
    description: 'תכנון פנסיוני וביטחון כלכלי לעתיד. אנחנו דואגים שהכסף שלך יעבוד בשבילך ביום שאחרי הפרישה.',
    icon: '💖',
    type: InsuranceType.LIFE
  }
];

const Services: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-mazuba-orange font-black tracking-widest uppercase mb-2">ההתמחויות שלנו</h2>
        <p className="text-4xl md:text-5xl font-black text-mazuba-blue">שירות מקצועי, אדיב ושקוף</p>
        <div className="w-24 h-2 bg-mazuba-orange mx-auto mt-6 rounded-full"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        {services.map((service) => (
          <div 
            key={service.id} 
            className={`group p-10 rounded-[2.5rem] border-2 transition-all duration-300 hover:shadow-3xl hover:-translate-y-2 ${
              service.type === InsuranceType.BUSINESS 
                ? 'bg-mazuba-lightBlue border-mazuba-blue/20 shadow-xl md:scale-105 z-10' 
                : 'bg-white border-gray-100 hover:border-mazuba-orange/30 shadow-sm'
            }`}
          >
            <div className="flex justify-between items-start mb-8">
              <div className="text-6xl transform group-hover:scale-110 group-hover:rotate-6 transition-transform">
                {service.icon}
              </div>
              {service.type === InsuranceType.BUSINESS && (
                <span className="bg-mazuba-orange text-white text-xs font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-md">מומחיות על</span>
              )}
            </div>
            <h3 className="text-2xl font-black text-mazuba-blue mb-4">{service.title}</h3>
            <p className="text-gray-600 leading-relaxed mb-8 text-lg">
              {service.description}
            </p>
            <button className="text-mazuba-blue font-black flex items-center group-hover:text-mazuba-orange transition-colors">
              למידע מקצועי נוסף
              <svg className="w-6 h-6 mr-2 transform rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </button>
          </div>
        ))}
      </div>
      
      <div className="mt-20 bg-gray-50 p-10 rounded-3xl border border-dashed border-mazuba-blue/30">
        <h4 className="text-xl font-black text-mazuba-blue mb-6">אנחנו מתמחים בביטוח אחריות מקצועית ל:</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-gray-700 font-medium">
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>ממוני ומהנדסי בטיחות וגיהות</div>
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>עורכי מבדקים במוסדות חינוך</div>
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>אגרונומים, אדריכלי נוף ואילנאים</div>
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>יועצי נגישות מתו"ס ומורשי נגישות</div>
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>יועצי בטיחות באתרי סלילה</div>
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>קציני בטיחות בתעבורה</div>
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>מהנדסים, הנדסאים ואדריכלים</div>
          <div className="flex items-center"><span className="text-mazuba-orange ml-2">✓</span>יועצי בטיחות אש</div>
        </div>
      </div>
    </div>
  );
};

export default Services;
