
import React from 'react';

interface FooterProps {
  onNavClick: (id: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavClick }) => {
  return (
    <footer className="bg-[#1a2c5a] text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-16 text-right">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-8 group cursor-pointer" onClick={() => onNavClick('home')}>
              <div className="w-12 h-12 bg-mazuba-orange rounded-lg flex items-center justify-center text-white font-bold text-2xl ml-4 shadow-xl">
                מ
              </div>
              <div className="flex flex-col">
                <span className="text-3xl font-black tracking-tight leading-none text-white">מצובה ביטוחים</span>
                <span className="text-base font-bold text-mazuba-orange leading-none mt-1">אורי קדושי סוכן ביטוח</span>
              </div>
            </div>
            <p className="text-blue-100/70 text-lg mb-10 max-w-md leading-relaxed">
              סוכנות הביטוח המשפחתית בקיבוץ מצובה. מתמחים באחריות מקצועית, בריאות ופנסיה בגישת "אנשים למען אנשים".
            </p>
            <div className="flex space-x-4 space-x-reverse">
              {['FB', 'IG', 'LI', 'WA'].map(social => (
                <button key={social} className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-mazuba-orange transition-all transform hover:-translate-y-1">
                  <span className="text-xs font-black">{social}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-xl font-black mb-8 text-mazuba-orange">ניווט מהיר</h4>
            <ul className="space-y-4 text-gray-300 font-bold">
              <li><button onClick={() => onNavClick('home')} className="hover:text-white transition-colors">דף הבית</button></li>
              <li><button onClick={() => onNavClick('services')} className="hover:text-white transition-colors">התמחויות</button></li>
              <li><button onClick={() => onNavClick('about')} className="hover:text-white transition-colors">אודותינו</button></li>
              <li><button onClick={() => onNavClick('accessibility')} className="hover:text-mazuba-orange transition-colors">הצהרת נגישות</button></li>
              <li><button onClick={() => onNavClick('contact')} className="hover:text-white transition-colors">צור קשר</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xl font-black mb-8 text-mazuba-orange">צור קשר</h4>
            <ul className="space-y-4 text-gray-300 font-bold">
              <li className="flex items-center justify-end">
                <span>א-ה: 08:00 - 16:30</span>
                <span className="mr-2 opacity-50">⏰</span>
              </li>
              <li className="flex items-center justify-end">
                <span dir="ltr">04-9858006</span>
                <span className="mr-2 opacity-50">📞</span>
              </li>
              <li className="flex items-center justify-end">
                <span dir="ltr">urikadoshi@matzuva.org.il</span>
                <span className="mr-2 opacity-50">📧</span>
              </li>
              <li className="flex items-center justify-end text-sm">
                <span>קיבוץ מצובה, דואר נע גליל מערבי</span>
                <span className="mr-2 opacity-50">📍</span>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Legal Disclaimer */}
        <div className="mt-20 pt-10 border-t border-white/10 text-right space-y-4">
          <p className="text-blue-100/60 text-xs leading-relaxed max-w-5xl mx-auto">
            המידע המופיע באתר הינו כללי בלבד. התנאים המחייבים הינם אלה המופיעים בתנאי הפוליסות של חברות הביטוח. אין לראות באמור באתר, משום ייעוץ פנסיוני או המלצה לרכישת מוצר מסויים או העדפתו על פני מוצר אחר. למען הסר ספק, מצובה ביטוחים עוסקת בשיווק פנסיוני ולא במתן ייעוץ פנסיוני.
          </p>
          <p className="text-blue-100/40 text-xs text-center">
            © {new Date().getFullYear()} מצובה ביטוחים | אורי קדושי - כל הזכויות שמורות. האתר מונגש ברמת AA.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
