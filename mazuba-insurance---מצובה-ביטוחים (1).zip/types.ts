
export enum InsuranceType {
  HEALTH = 'בריאות',
  LIFE = 'חיים',
  BUSINESS = 'אחריות מקצועית',
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  type: InsuranceType;
}

export interface ContactMessage {
  name: string;
  phone: string;
  email: string;
  service: InsuranceType | '';
  message: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
