
import React from 'react';

interface HeroProps {
  onContactClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onContactClick }) => {
  return (
    <div className="relative bg-mazuba-blue overflow-hidden min-h-[85vh] flex items-center">
      <div className="absolute inset-0 opacity-15">
        <img 
          src="https://images.unsplash.com/photo-1454165833767-027ffea9e77b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80" 
          alt="Professional Business Insurance" 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Abstract protection hands pattern (hinting at logo) */}
      <div className="absolute right-0 top-0 w-1/3 h-full opacity-10 pointer-events-none">
        <svg viewBox="0 0 100 100" className="w-full h-full text-white fill-current">
          <path d="M50 10 L80 40 L80 70 L50 90 L20 70 L20 40 Z" />
        </svg>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
        <div className="md:w-2/3">
          <h1 className="text-5xl md:text-7xl font-black text-white leading-tight mb-6">
            ביטחון מקצועי <br />
            <span className="text-mazuba-orange italic">בשקט נפשי מלא.</span>
          </h1>
          <p className="text-xl md:text-2xl text-blue-50 mb-10 max-w-2xl font-medium leading-relaxed">
            מצובה ביטוחים מובילה את תחום האחריות המקצועית בישראל. עם הניסיון של אורי קדושי, העסק והמוניטין שלך בידיים הבטוחות ביותר.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={onContactClick}
              className="bg-mazuba-orange hover:bg-white hover:text-mazuba-blue text-white px-10 py-5 rounded-2xl text-xl font-black transition-all shadow-2xl hover:shadow-mazuba-orange/30 transform hover:-translate-y-1"
            >
              לייעוץ מקצועי עם אורי
            </button>
          </div>
          
          <div className="mt-12 flex items-center space-x-6 space-x-reverse">
            <div className="flex -space-x-4 space-x-reverse">
              {[1, 2, 3, 4].map((i) => (
                <img 
                  key={i} 
                  className="w-14 h-14 rounded-full border-4 border-mazuba-blue" 
                  src={`https://i.pravatar.cc/150?u=biz${i}`} 
                  alt="Professional Customer" 
                />
              ))}
            </div>
            <p className="text-white font-bold text-lg">
              <span className="text-mazuba-orange">1,000+</span> בעלי מקצוע כבר מוגנים אצלנו
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
