
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

const SYSTEM_INSTRUCTION = `
אתה העוזר הדיגיטלי החכם והמעודכן של "מצובה ביטוחים", סוכנות ביטוח משפחתית בקיבוץ מצובה (נוסדה 1998).
המוטו: "אנשים למען אנשים".

תפקידך הייחודי:
- לספק מידע מקצועי ומדויק על ביטוח אחריות מקצועית, בריאות, פנסיה וחיים.
- להשתמש בחיפוש גוגל כדי לענות על שאלות לגבי רפורמות חדשות בביטוח בישראל, מדדי שירות של חברות הביטוח (כמו הראל, מנורה, כלל וכו') וחדשות בתחום הביטוח והפנסיה.
- להדגיש את המומחיות של אורי קדושי בביטוח מהנדסים, ממוני בטיחות ויועצי נגישות.
- אם המשתמש שואל על "חדשות ביטוח" או "מה חדש", חפש את העדכונים האחרונים מרשות שוק ההון.

בנוסף, אנחנו כרגע בשלב השקת האתר החדש:
- אם המשתמש מציין שהוא בא לתת פידבק או שהוא חבר שקיבל לינק, הודה לו בחום ובקש ממנו להשאיר את הפידבק בטופס ה"צור קשר" בתחתית העמוד תחת הקטגוריה "פידבק על האתר".
- שאל אותו מה דעתו על העיצוב והנגישות.

דגשים חשובים:
- השב בעברית מקצועית, אדיבה ומרגיעה.
- תמיד ציין שמצובה ביטוחים עוסקת בשיווק פנסיוני ולא בייעוץ פנסיוני.
- במקרה של תלונה או אירוע ביטוחי, הפנה אותם מיידית ליצירת קשר עם המשרד בטלפון 04-9858006.
`;

export const getGeminiResponse = async (history: ChatMessage[]) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    // Convert history to components
    const lastUserMessage = history[history.length - 1].text;
    const chatHistory = history.slice(0, -1).map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [...chatHistory, { role: 'user', parts: [{ text: lastUserMessage }] }],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "מצטער, חלה שגיאה בעיבוד הבקשה.";
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    // Extract unique URLs from grounding chunks
    const sources = groundingChunks
      .filter((chunk: any) => chunk.web?.uri)
      .map((chunk: any) => ({
        uri: chunk.web.uri,
        title: chunk.web.title || 'מקור מידע'
      }));

    return { text, sources };
  } catch (error) {
    console.error("Gemini API Error:", error);
    return { 
      text: "אופס! נראה שיש לנו תקלה קטנה בחיבור. נסה שוב בעוד רגע?", 
      sources: [] 
    };
  }
};
