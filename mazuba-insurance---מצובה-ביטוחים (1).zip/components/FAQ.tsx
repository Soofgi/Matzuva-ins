
import React, { useState } from 'react';

const faqData = [
  {
    question: "מה זה בדיוק ביטוח אחריות מקצועית?",
    answer: "זהו ביטוח המגן עליך מפני תביעות בגין טעויות, השמטות או רשלנות שבוצעו במסגרת עבודתך המקצועית. הוא מכסה הוצאות הגנה משפטית ופיצויים לצד ג'."
  },
  {
    question: "האם אורי קדושי מלווה אותי באופן אישי?",
    answer: "חד משמעית כן. אורי מאמין בגישת הבוטיק וכל תיק אחריות מקצועית עובר תחת עינו המקצועית, במיוחד בשלב בניית הפוליסה וניהול תביעות מורכבות."
  },
  {
    question: "אילו מקצועות חייבים ביטוח אחריות מקצועית?",
    answer: "רופאים, עורכי דין, מהנדסים, אדריכלים, רואי חשבון וסוכני ביטוח מחויבים או זקוקים לכך מאוד. גם יועצים עסקיים, מנהלי פרויקטים ובעלי מקצועות פרא-רפואיים זקוקים להגנה זו."
  },
  {
    question: "מה היתרון שלכם על פני חברות ביטוח ישירות?",
    answer: "בחברות ישירות אתם מספר. אצלנו, בזכות הקשרים של אורי עם הנהלות חברות הביטוח, אנחנו יודעים לתפור כיסויים חריגים ולהשיג אישורים שלא ניתן לקבל דרך מוקד טלפוני רגיל."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-blue-600 font-bold tracking-widest uppercase mb-2">שאלות נפוצות</h2>
        <p className="text-3xl font-black text-gray-900">כל מה שחשוב לדעת</p>
      </div>

      <div className="space-y-4 text-right">
        {faqData.map((item, index) => (
          <div key={index} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <button 
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full p-6 text-right flex justify-between items-center hover:bg-gray-50 transition-colors focus:outline-none"
              aria-expanded={openIndex === index}
            >
              <span className="font-bold text-lg text-gray-900">{item.question}</span>
              <span className={`transform transition-transform duration-300 text-blue-600 ${openIndex === index ? 'rotate-180' : ''}`}>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </span>
            </button>
            {openIndex === index && (
              <div className="px-6 pb-6 text-gray-600 leading-relaxed animate-in fade-in slide-in-from-top-2">
                {item.answer}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQ;
