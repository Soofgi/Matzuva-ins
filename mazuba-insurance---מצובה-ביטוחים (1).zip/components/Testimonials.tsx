
import React from 'react';

const reviews = [
  {
    name: "יוסי כהן",
    role: "לקוח בביטוח עסקי",
    text: "השירות הכי מקצועי שקיבלתי. כשהייתה לי פריצה בעסק, הצוות של מצובה נלחם מול חברת הביטוח עד שקיבלתי כל שקל שמגיע לי.",
    rating: 5,
    img: "https://i.pravatar.cc/150?u=yossi"
  },
  {
    name: "מיכל לוי",
    role: "לקוחה בביטוח רכב ודירה",
    text: "תמיד זמינים, תמיד אדיבים. מרגישים שיש על מי לסמוך ולא סתם עוד מספר במערכת של חברה גדולה.",
    rating: 5,
    img: "https://i.pravatar.cc/150?u=michal"
  },
  {
    name: "דוד אברהם",
    role: "לקוח פנסיוני",
    text: "עשו לי סדר בכל הקופות והחסכונות. פתאום אני מבין לאן הכסף שלי הולך וכמה אני עומד לקבל בפרישה. פשוט מצוין.",
    rating: 5,
    img: "https://i.pravatar.cc/150?u=david"
  }
];

const Testimonials: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-blue-600 font-bold tracking-widest uppercase mb-2">מה אומרים עלינו</h2>
        <p className="text-4xl font-black text-gray-900">הלקוחות שלנו הם השגרירים הכי טובים</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {reviews.map((review, index) => (
          <div key={index} className="bg-white p-8 rounded-3xl shadow-xl shadow-blue-900/5 relative border border-gray-50">
            <div className="flex items-center mb-6">
              <img src={review.img} alt={review.name} className="w-14 h-14 rounded-full mr-4 border-2 border-blue-100" />
              <div>
                <h4 className="font-bold text-gray-900">{review.name}</h4>
                <p className="text-sm text-gray-500">{review.role}</p>
              </div>
            </div>
            <div className="flex mb-4">
              {[...Array(review.rating)].map((_, i) => (
                <svg key={i} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <p className="text-gray-600 italic leading-relaxed">"{review.text}"</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Testimonials;
