
import React from 'react';

const AccessibilityStatement: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-gray-50 rounded-3xl p-8 md:p-12 my-20">
      <h2 className="text-3xl font-black text-gray-900 mb-6 text-center">הצהרת נגישות</h2>
      <div className="space-y-6 text-gray-700 leading-relaxed text-right">
        <p>
          אנו במצובה ביטוחים רואים חשיבות עליונה במתן שירות שוויוני ונגיש לכלל הלקוחות, לרבות אנשים עם מוגבלות. האתר הונגש בהתאם לתקנות שוויון זכויות לאנשים עם מוגבלות (התאמות נגישות לשירות), תשע"ג-2013 ובהתאם להמלצות התקן הישראלי (ת"י 5568) ברמה AA.
        </p>
        
        <h3 className="text-xl font-bold text-gray-900">אמצעי הנגישות באתר:</h3>
        <ul className="list-disc list-inside space-y-2 mr-4">
          <li>תמיכה בכל הדפדפנים המודרניים הנפוצים.</li>
          <li>ניווט מלא באמצעות המקלדת.</li>
          <li>התאמה לקוראי מסך.</li>
          <li>סרגל נגישות ייעודי לשינוי תצוגה.</li>
          <li>מבנה סמנטי מסודר המקל על התמצאות.</li>
        </ul>

        <h3 className="text-xl font-bold text-gray-900">פרטי רכז הנגישות:</h3>
        <p>
          אם נתקלתם בקושי בגלישה באתר או שיש לכם הצעה לשיפור, נשמח לשמוע:
          <br />
          <strong>רכז נגישות:</strong> אורי קדושי
          <br />
          <strong>דוא"ל:</strong> urikadoshi@matzuva.org.il
          <br />
          <strong>טלפון:</strong> 04-9858006
        </p>
        <p className="text-sm text-gray-500 italic">תאריך עדכון הצהרה: {new Date().toLocaleDateString('he-IL')}</p>
      </div>
    </div>
  );
};

export default AccessibilityStatement;
