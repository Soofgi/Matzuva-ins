
import React from 'react';

const OfficeLocation: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-white rounded-[3rem] overflow-hidden shadow-xl border border-gray-100 flex flex-col md:flex-row">
        <div className="md:w-1/2 p-10 md:p-16 flex flex-col justify-center">
          <div className="inline-block px-4 py-1 rounded-full bg-mazuba-blue/10 text-mazuba-blue font-black text-sm mb-4 w-fit">
            בואו לבקר אותנו
          </div>
          <h2 className="text-4xl font-black text-mazuba-blue mb-6">המשרד בקיבוץ מצובה</h2>
          <p className="text-lg text-gray-600 mb-8 leading-relaxed">
            המשרד שלנו ממוקם בלב קיבוץ מצובה שבגליל המערבי. אנחנו מאמינים שביטוח עושים פנים אל פנים, באווירה גלילית ורגועה.
          </p>
          
          <div className="space-y-4 mb-10">
            <div className="flex items-start">
              <span className="text-2xl ml-3">📍</span>
              <div>
                <p className="font-bold text-gray-900">כתובת למשלוח דואר:</p>
                <p className="text-gray-600">קיבוץ מצובה, דואר נע גליל מערבי, מיקוד 2283500</p>
              </div>
            </div>
            <div className="flex items-start">
              <span className="text-2xl ml-3">⏰</span>
              <div>
                <p className="font-bold text-gray-900">שעות פעילות:</p>
                <p className="text-gray-600">א' - ה': 08:00 - 16:30</p>
              </div>
            </div>
          </div>

          <a 
            href="https://www.google.com/maps/search/?api=1&query=קיבוץ+מצובה" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center bg-mazuba-blue text-white px-8 py-4 rounded-2xl font-black text-lg hover:bg-mazuba-orange transition-all shadow-lg w-full md:w-fit"
          >
            <span className="ml-2">🚙</span>
            ניווט למשרד ב-Google Maps
          </a>
        </div>
        
        <div className="md:w-1/2 h-[400px] md:h-auto bg-gray-200 relative">
          {/* Static Map Image Placeholder - In a real app we'd use a Google Maps Embed or API */}
          <img 
            src="https://images.unsplash.com/photo-1526772662000-3f88f10405ff?q=80&w=1000&auto=format&fit=crop" 
            alt="קיבוץ מצובה" 
            className="w-full h-full object-cover grayscale opacity-50"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-white/90 backdrop-blur p-6 rounded-3xl shadow-2xl border border-mazuba-orange text-center max-w-xs">
              <div className="w-12 h-12 bg-mazuba-orange rounded-full mx-auto mb-4 flex items-center justify-center text-white text-2xl animate-bounce">
                📍
              </div>
              <p className="font-black text-mazuba-blue text-xl">מצובה ביטוחים</p>
              <p className="text-sm text-gray-500 font-bold mt-1">אנחנו כאן בתוך הקיבוץ</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfficeLocation;
