
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col lg:flex-row items-center gap-16">
        <div className="lg:w-1/2 flex justify-center">
          <div className="relative group">
            {/* 
               Using a high-quality professional generic image that fits the 
               "Family Insurance Agency" and "People for People" vibe.
            */}
            <div className="relative z-10 overflow-hidden rounded-[3rem] shadow-2xl border-8 border-white transform transition-transform duration-500 group-hover:scale-[1.02]">
              <img 
                src="https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=1000&auto=format&fit=crop" 
                alt="אורי קדושי - מצובה ביטוחים" 
                className="w-full max-w-sm h-[600px] object-cover object-top"
                loading="lazy"
              />
            </div>
            
            {/* Decorative background elements */}
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-mazuba-blue/10 rounded-full blur-3xl -z-0"></div>
            <div className="absolute -top-10 -left-10 w-48 h-48 bg-mazuba-orange/20 rounded-full blur-2xl -z-0"></div>
            
            {/* Floating badge */}
            <div className="absolute -bottom-6 -left-6 lg:left-auto lg:-right-6 z-20 bg-white/95 backdrop-blur-md p-6 rounded-2xl shadow-2xl border-r-8 border-mazuba-orange min-w-[260px] transform -rotate-2">
              <p className="font-black text-2xl text-mazuba-blue">אורי קדושי</p>
              <p className="text-gray-600 font-bold">מייסד "מצובה ביטוחים"</p>
              <div className="mt-2 text-mazuba-orange font-black italic">"אנשים למען אנשים"</div>
            </div>
          </div>
        </div>
        
        <div className="lg:w-1/2">
          <div className="inline-block px-4 py-1 rounded-full bg-mazuba-orange/10 text-mazuba-orange font-black tracking-widest uppercase mb-4 text-sm">
            הסיפור שלנו
          </div>
          <h3 className="text-4xl md:text-5xl font-black text-mazuba-blue mb-8 leading-tight">
            ביטוח זה קודם כל <br />
            <span className="text-mazuba-orange">האנשים שמאחוריו.</span>
          </h3>
          <div className="space-y-6 text-lg text-gray-600 leading-relaxed text-right">
            <p>
              סוכנות הביטוח המשפחתית - **מצובה ביטוחים** הוקמה בשנת 1998 ע"י אורי קדושי בקיבוץ מצובה שבגליל המערבי. מיום הקמתה, הסוכנות חרטה על דגלה שירות המבוסס על ערכי הקיבוץ: ערבות הדדית, שקיפות ומחויבות אישית עמוקה.
            </p>
            <p>
              אנחנו לא מאמינים ב"מספרים", אנחנו מאמינים בפנים. כשאתם מבטחים אצלנו אחריות מקצועית, בריאות או פנסיה, אתם מקבלים שותף לדרך שמכיר אתכם בשמכם הפרטי.
            </p>
            <div className="p-6 bg-mazuba-lightBlue rounded-2xl border-r-4 border-mazuba-blue font-bold text-mazuba-blue italic">
              "בזכות הניסיון ואהבת האדם, אנו מעניקים ערך של נאמנות ויצירתיות לכל לקוחותינו, תוך ליווי אישי ברגעי האמת."
            </div>
          </div>
          
          <div className="mt-12 grid grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <p className="text-4xl font-black text-mazuba-blue mb-1">1998</p>
              <p className="text-gray-500 font-bold">נוסדנו בגליל</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <p className="text-4xl font-black text-mazuba-blue mb-1">25+</p>
              <p className="text-gray-500 font-bold">שנות ניסיון</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
