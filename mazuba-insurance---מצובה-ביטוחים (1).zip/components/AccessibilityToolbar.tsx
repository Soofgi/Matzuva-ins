
import React, { useState, useEffect } from 'react';

const AccessibilityToolbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [fontSize, setFontSize] = useState(100);
  const [contrast, setContrast] = useState(false);
  const [grayscale, setGrayscale] = useState(false);
  const [underlineLinks, setUnderlineLinks] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    root.style.fontSize = `${fontSize}%`;
    
    if (contrast) root.classList.add('high-contrast');
    else root.classList.remove('high-contrast');

    if (grayscale) root.classList.add('grayscale-filter');
    else root.classList.remove('grayscale-filter');

    if (underlineLinks) root.classList.add('underline-links');
    else root.classList.remove('underline-links');

  }, [fontSize, contrast, grayscale, underlineLinks]);

  const reset = () => {
    setFontSize(100);
    setContrast(false);
    setGrayscale(false);
    setUnderlineLinks(false);
  };

  return (
    <div className="fixed top-28 left-4 z-[70] dir-rtl">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-12 h-12 bg-mazuba-blue text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-mazuba-orange transition-all focus:ring-4 focus:ring-mazuba-orange/50"
        aria-label="פתח תפריט נגישות"
        title="נגישות"
      >
        <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute top-14 left-0 w-64 bg-white rounded-2xl shadow-2xl border border-gray-100 p-4 animate-in fade-in slide-in-from-left-2 overflow-hidden">
          <div className="bg-mazuba-blue -m-4 p-4 mb-4 text-white">
            <h3 className="text-lg font-black">תפריט נגישות</h3>
          </div>
          
          <div className="space-y-2 mt-4">
            <button 
              onClick={() => setFontSize(prev => Math.min(prev + 10, 130))}
              className="w-full text-right p-3 hover:bg-mazuba-lightBlue rounded-xl flex items-center justify-between font-bold"
            >
              <span>הגדל טקסט</span>
              <span className="text-mazuba-orange font-black">+</span>
            </button>
            <button 
              onClick={() => setFontSize(prev => Math.max(prev - 10, 80))}
              className="w-full text-right p-3 hover:bg-mazuba-lightBlue rounded-xl flex items-center justify-between font-bold"
            >
              <span>הקטן טקסט</span>
              <span className="text-mazuba-orange font-black">-</span>
            </button>
            <button 
              onClick={() => setContrast(!contrast)}
              className={`w-full text-right p-3 rounded-xl flex items-center justify-between font-bold transition-colors ${contrast ? 'bg-mazuba-orange text-white' : 'hover:bg-mazuba-lightBlue text-gray-700'}`}
            >
              <span>ניגודיות גבוהה</span>
              <span className="text-lg">🌓</span>
            </button>
            <button 
              onClick={() => setGrayscale(!grayscale)}
              className={`w-full text-right p-3 rounded-xl flex items-center justify-between font-bold transition-colors ${grayscale ? 'bg-mazuba-orange text-white' : 'hover:bg-mazuba-lightBlue text-gray-700'}`}
            >
              <span>גווני אפור</span>
              <span className="text-lg">🌑</span>
            </button>
            <button 
              onClick={() => setUnderlineLinks(!underlineLinks)}
              className={`w-full text-right p-3 rounded-xl flex items-center justify-between font-bold transition-colors ${underlineLinks ? 'bg-mazuba-orange text-white' : 'hover:bg-mazuba-lightBlue text-gray-700'}`}
            >
              <span>הדגשת קישורים</span>
              <span className="text-lg">🔗</span>
            </button>
            <div className="pt-4 border-t mt-4">
              <button 
                onClick={reset}
                className="w-full text-center p-3 bg-gray-100 text-gray-700 rounded-xl font-black hover:bg-gray-200 transition-colors"
              >
                איפוס הגדרות
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccessibilityToolbar;
