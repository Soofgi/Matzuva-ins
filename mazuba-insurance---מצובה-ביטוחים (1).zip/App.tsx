
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import ContactForm from './components/ContactForm';
import OfficeLocation from './components/OfficeLocation';
import AIAssistant from './components/AIAssistant';
import WhatsAppButton from './components/WhatsAppButton';
import AccessibilityToolbar from './components/AccessibilityToolbar';
import AccessibilityStatement from './components/AccessibilityStatement';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'services', 'reviews', 'faq', 'about', 'location', 'accessibility', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + height) {
            setActiveSection(section);
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <AccessibilityToolbar />
      <Navbar 
        activeSection={activeSection} 
        onNavClick={scrollToSection} 
      />
      
      <main id="main-content" className="flex-grow">
        <section id="home">
          <Hero onContactClick={() => scrollToSection('contact')} />
        </section>
        
        <section id="services" className="py-20 bg-white">
          <Services />
        </section>

        <section id="reviews" className="py-20 bg-gray-50">
          <Testimonials />
        </section>

        <section id="faq" className="py-20 bg-white">
          <FAQ />
        </section>
        
        <section id="about" className="py-20 bg-gray-100">
          <About />
        </section>

        <section id="location" className="py-20 bg-gray-50">
          <OfficeLocation />
        </section>

        <section id="accessibility" className="py-20 bg-white">
          <AccessibilityStatement />
        </section>
        
        <section id="contact" className="py-20 bg-white">
          <ContactForm />
        </section>
      </main>

      <Footer onNavClick={scrollToSection} />
      
      <AIAssistant />
      <WhatsAppButton />
    </div>
  );
};

export default App;
